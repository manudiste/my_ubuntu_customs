Il file c.lang contiene le modifiche necessarie da apportare
per avere i miei highlight dei *.c in gedit.

Il file yaru-alt-dark.xml contiene le conseguenti modifiche
al color scheme (dipendenti da c.lang).

Nel file di testo c'e' un piccolo tutorial per effettuare
queste modifiche.
